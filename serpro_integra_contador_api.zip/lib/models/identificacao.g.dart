// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'identificacao.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Identificacao _$IdentificacaoFromJson(Map<String, dynamic> json) =>
    Identificacao(
      cpf: json['cpf'] as String?,
      cnpj: json['cnpj'] as String?,
      tipoNi: json['tipoNi'] == null
          ? null
          : TipoNi.fromJson(json['tipoNi'] as Map<String, dynamic>),
      numero: json['numero'] as String?,
    );

Map<String, dynamic> _$IdentificacaoToJson(Identificacao instance) =>
    <String, dynamic>{
      'cpf': instance.cpf,
      'cnpj': instance.cnpj,
      'tipoNi': instance.tipoNi,
      'numero': instance.numero,
    };
