// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dados_saida.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DadosSaida _$DadosSaidaFromJson(Map<String, dynamic> json) => DadosSaida(
  resultado: json['resultado'] as String?,
  dados: json['dados'] as Map<String, dynamic>?,
  status: json['status'] as String?,
  codigo: json['codigo'] as String?,
  mensagem: json['mensagem'] as String?,
  timestamp: json['timestamp'] == null
      ? null
      : DateTime.parse(json['timestamp'] as String),
  numeroProtocolo: json['numero_protocolo'] as String?,
);

Map<String, dynamic> _$DadosSaidaToJson(DadosSaida instance) =>
    <String, dynamic>{
      'resultado': instance.resultado,
      'dados': instance.dados,
      'status': instance.status,
      'codigo': instance.codigo,
      'mensagem': instance.mensagem,
      'timestamp': instance.timestamp?.toIso8601String(),
      'numero_protocolo': instance.numeroProtocolo,
    };
